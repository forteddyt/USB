import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SwingQuiz2
{
    private JFrame frame;
    private JPanel bigPanel;
    private JTextField nameBox;
    private JLabel nameLabel;

    public static void main(String[] args)
    {
        new SwingQuiz2();
    }

    public SwingQuiz2()
    {
        frame = new JFrame("The SOL");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setResizable(false);

        bigPanel = new JPanel();
        bigPanel.setLayout(new BorderLayout());

        bigPanel.add(new NameComponent(), BorderLayout.PAGE_START);
        bigPanel.add(new QuestionComponent(), BorderLayout.CENTER);
        bigPanel.add(new AnswerComponent(), BorderLayout.PAGE_END);

        frame.add(bigPanel);
        frame.setVisible(true);
    }

    private class NameComponent extends JPanel
    {
        public NameComponent()
        {
            setLayout(new BorderLayout());

            nameLabel = new JLabel("Type your name: ");
            nameLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
            nameLabel.setForeground(Color.white);
            nameBox = new JTextField("", 15);

            add(nameLabel, BorderLayout.LINE_START);
            add(nameBox, BorderLayout.CENTER);

            setBackground(Color.black);
            setBorder(BorderFactory.createLineBorder(Color.black, 20));
        }
    }

    private class QuestionComponent extends JPanel
    {
        public QuestionComponent()
        {
            setBorder(BorderFactory
                    .createLineBorder(new Color(0, 138, 184), 20));
            setLayout(new GridLayout(2, 1));
            add(new Questions(1));
            add(new Questions(2));
        }

        private class Questions extends JPanel
        {
            ButtonGroup bg = new ButtonGroup();
            String[] answerSet1 =
            { "cemetery", "sematary", "cemetary", "cematery" };
            String[] answerSet2 =
            { "acomodate", "acommodate", "accommodate", "accomodate" };
            String q1 = "1. This word, a synonym for graveyard, has its origins in the Latin word coimeterium and the Greek word koimetrion, meaning \"a sleeping place.\"";
            String q2 = "2. How do you spell the word which has various meanings including \"to oblige\" and \"to provide with a room.\"";

            public ButtonGroup getbg()
            {
                return bg;
            }

            public Questions(int num)
            {
                setBorder(BorderFactory.createLineBorder(new Color(153, 204,
                        255), 14));
                setLayout(new BorderLayout());

                JTextArea question = new JTextArea();
                JPanel answerPanel = new JPanel();
                answerPanel.setLayout(new GridLayout(4, 1));
                question.setWrapStyleWord(true);
                question.setLineWrap(true);
                question.setEditable(false);
                question.setFocusable(false);
                if (num == 1)
                {
                    question.setText(q1);
                    question.setFont(new Font("Comic Sans MS", Font.PLAIN, 10));
                    question.setBackground(new Color(255, 255, 204));
                    question.setBorder(BorderFactory.createLineBorder(
                            new Color(255, 255, 204), 10));
                    question.setOpaque(true);

                    for (int i = 0; i < 4; i++)
                    {
                        JRadioButton answers = new JRadioButton(answerSet1[i]);
                        bg.add(answers);
                        answerPanel.add(answers);
                    }
                } else if (num == 2)
                {
                    question.setText(q2);
                    question.setFont(new Font("Comic Sans MS", Font.PLAIN, 10));
                    question.setBackground(new Color(255, 255, 204));
                    question.setBorder(BorderFactory.createLineBorder(
                            new Color(255, 255, 204), 10));
                    question.setOpaque(true);

                    for (int i = 0; i < 4; i++)
                    {
                        JRadioButton answers = new JRadioButton(answerSet2[i]);
                        bg.add(answers);
                        answerPanel.add(answers);
                    }
                }
                add(question, BorderLayout.PAGE_START);
                add(answerPanel, BorderLayout.CENTER);
            }
        }
    }

    private class AnswerComponent extends JButton implements MouseListener
    {
        public AnswerComponent()
        {
            setText("Submit");
            setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
            setBackground(Color.black);
            setForeground(Color.white);
            setBorder(BorderFactory.createLineBorder(Color.white, 5));
        }

        @Override
        public void mouseClicked(MouseEvent arg0)
        {
            // TODO Auto-generated method stub

        }

        @Override
        public void mouseEntered(MouseEvent arg0)
        {
            // TODO Auto-generated method stub

        }

        @Override
        public void mouseExited(MouseEvent arg0)
        {
            // TODO Auto-generated method stub

        }

        @Override
        public void mousePressed(MouseEvent arg0)
        {
            // TODO Auto-generated method stub

        }

        @Override
        public void mouseReleased(MouseEvent m)
        {
        }
    }
}
